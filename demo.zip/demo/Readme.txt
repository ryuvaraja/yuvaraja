1.	Used for bootstrap 4 and angular 1.6
2. 	Extract the zip folder and run the index.html file.
3. 	Click the right side block iteam it will point the location in map and it will show the details also.
